package Project.ij001.controller;

public class Test {

	public static void main(String[] args) {
		String s1 = ",zohodeveloper";
		String s2 = s1.replaceAll("[^a-zA-Z]", "");
		System.out.println(s2);

	}

}
