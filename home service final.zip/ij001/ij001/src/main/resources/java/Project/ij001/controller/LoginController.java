package Project.ij001.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import Project.ij001.model.Login;
import Project.ij001.model.VendorModel;

@Controller
public class LoginController {
	private DBClass dbclass = new DBClass();
	String userName;

	@RequestMapping(value = "/ResultPage1", method = RequestMethod.POST)
	public String ResultPage1(@ModelAttribute("login") Login login,ModelMap model,HttpSession request) {
		//model.addAttribute("login", new Login());
		String role = login.getRole();
		String userName = login.getuserName();
		int flag = dbclass.check(login);
		
		if (flag == 1) {
			
			
		
			//model.put("userName", userName); 	
			if (role.equals("vendor"))
			{
				request.setAttribute("user",userName);
				return "redirect:/vendor";
				}
			if (role.equals("customer"))
			{	request.setAttribute("user",userName);
				System.out.println(userName);
				return "redirect:/user";
			}
			if (role.equals("admin"))
			{
				request.setAttribute("user",userName);
				return "redirect:/admin";
			}
		}
		return "InvalidLogin";
	}
	

	public String getuserName() {
		return userName;
	}
}
