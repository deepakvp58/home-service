package Project.ij001.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.context.annotation.Configuration;

import Project.ij001.model.Login;
import Project.ij001.model.Registration;

@Configuration
public class DBClass {
	private DBHandler db = new DBHandler();

	public void setValues(Registration registration) {
		@NotNull(message = "First name can not be null")
		@Pattern(regexp = "{A-Za-z0-9}*")
		String firstName = registration.getFirstName();

		String lastName = registration.getLastName();

		String email = registration.getemail();

		String gender = registration.getGender();

		String contactNum = registration.getContactNum();

		String age = registration.getage();

		String skill = registration.getSkill();

		String password = registration.getPassword();

		String money = registration.getMoney();

		String roles = registration.getRoles();

		String vendorid = registration.getVendorid();
		String description = registration.getDescription();

		Connection conn = db.establishConnection();
		String description1 = description.replaceAll("[^a-zA-Z]+", "");
		//String email1=email.replaceAll("[^a-zA-Z]+", "");

		if (!(roles.equals("vendor")))

			vendorid = null;

		PreparedStatement mystmt;

		try {

			mystmt = conn.prepareStatement(
					"insert into users(firstname,lastname,contactno,email,password,age,gender,skills,money,roles,vendorid,description)"
							+ "values(?,?,?,?,?,?,?,?,?,?,?,?)");

			mystmt.setString(1, firstName);

			mystmt.setString(2, lastName);

			mystmt.setString(3, contactNum);

			mystmt.setString(4, email);

			mystmt.setString(5, password);

			mystmt.setString(6, age);

			mystmt.setString(7, gender);

			mystmt.setString(8, skill);

			mystmt.setString(9, money);

			mystmt.setString(10, roles);

			mystmt.setString(11, vendorid);
			mystmt.setString(12, description1);

			mystmt.execute();

		} catch (SQLException e) {

			e.printStackTrace();

		}

	}

	public int check(Login login) {
		String username = login.getuserName();
		String password = login.getPassword();
		String role = login.getRole();
//		System.out.println(username);
//		System.out.println(password);
//		System.out.println(role);
		Connection conn = db.establishConnection();
		PreparedStatement mystmt;
		int flag = 0;
		try {
			mystmt = conn.prepareStatement(
					"select password from users where email='" + username + "'and roles= '" + role + "';");
			ResultSet rs = mystmt.executeQuery();
			//System.out.println(rs.getString(1));
			while (rs.next()) {
				if (rs.getString(1).equals(password)) {
					flag = 1;
					break;
				} else {
					flag = 0;
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

}
