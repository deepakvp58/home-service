package Project.ij001.controller;
import java.io.*;
import java.sql.*;
import java.util.*;

import Project.ij001.model.Login;
public class DBHandler {

public Connection establishConnection(){
   	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	//Retrieving properties from db.properties
	String url="jdbc:mysql://localhost:3306/test?autoReconnect=true&useSSL=true";
	String username="root";
	String password="root";
	Connection connection=null;
	//Establishing connection and catching exception if connection is not established or url not found
	try {
		connection = DriverManager.getConnection(url,username,password);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	return connection;
}
}