package Project.ij001.model;

import java.util.ArrayList;
import java.util.List;

public class VendorModel {

	private String firstname;
	private String lastname;
	private String contactno;
	private String age;
	private String serviceno;
	private String name;
	private String vendorcat;
	private String newcat;
	private String location;
	private String service;
	private String vid;
	private int amt;
	private String submit;
	private String sname;
	private String lcn;
	private String amountedit;
	private List<String> servicename = new ArrayList<String>();
	private List<String> servicenumber = new ArrayList<String>();
	private List<String> locationlist = new ArrayList<String>();
	private List<String> category = new ArrayList<String>();
	private List<String> amount = new ArrayList<String>();
	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
		//System.out.println(sname);
	}

	public String getLcn() {
		return lcn;
	}

	public void setLcn(String lcn) {
		this.lcn = lcn;
	}
	public String getSubmit() {
		return submit;
	}

	public void setSubmit(String submit) {
		this.submit = submit;
	}
	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getContactno() {
		return contactno;
	}

	public void setContactno(String contactno) {
		this.contactno = contactno;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getNewcat() {
		return newcat;
	}

	public void setNewcat(String newcat) {
		this.newcat = newcat;
	}

	public String getVendorcat() {

		return vendorcat;
	}

	public void setVendorcat(String vendorcat) {
		this.vendorcat = vendorcat;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public int getAmt() {
		return amt;
	}

	public void setAmt(int amt) {
		this.amt = amt;
	}

	public String getVid() {
		return vid;
	}

	public void setVid(String id) {
		this.vid = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	public void setserviceName(List<String> servicename)
	{
		this.servicename = servicename;
	}
	public List<String> getserviceName()
	{
		return servicename;
	}

	public List<String> getLocationlist() {
		return locationlist;
	}

	public void setLocationlist(List<String> locationlist) {
		this.locationlist = locationlist;
	}

	public List<String> getCategory() {
		return category;
	}

	public void setCategory(List<String> category) {
		this.category = category;
	}

	public String getServiceno() {
		return serviceno;
	}

	public void setServiceno(String serviceno) {
		this.serviceno = serviceno;
	}

	public List<String> getAmount() {
		return amount;
	}

	public void setAmount(List<String> amount) {
		this.amount = amount;
	}

	public List<String> getServicenumber() {
		return servicenumber;
	}

	public void setServicenumber(List<String> servicenumber) {
		this.servicenumber = servicenumber;
	}

	public String getAmountedit() {
		return amountedit;
	}

	public void setAmountedit(String amountedit) {
		this.amountedit = amountedit;
	}

}
