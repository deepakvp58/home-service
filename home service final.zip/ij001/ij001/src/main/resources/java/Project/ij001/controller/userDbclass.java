package Project.ij001.controller;



import java.sql.Connection;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.sql.Statement;

import java.util.ArrayList;

import java.util.Date;

import java.util.List;



import org.springframework.context.annotation.Configuration;

import com.mysql.cj.protocol.Resultset;

import Project.ij001.model.Login;
import Project.ij001.model.Registration;

import Project.ij001.model.User;

@Configuration

public class userDbclass {



private static DBHandler db = new DBHandler();

 public List<ArrayList<String>> search(User user) {

 // TODO Auto-generated method stub\



 String catagory=user.getUsercat();

 String location=user.getUserloc();

 System.out.println(catagory);

      System.out.println(location);



 Connection conn=db.establishConnection();

 Statement stmt = null;



 try {

  stmt = conn.createStatement();

  if((!location.equals("default")) &&(!catagory.equals("default")))

  {

  String sql = "SELECT * FROM services where catagory='"+catagory+"' and location='"+location+"';";

  ResultSet rs = stmt.executeQuery(sql);

  List<String> servicename = new ArrayList<String>();

  List<String> serviceno = new ArrayList<String>();

  List<String> cat = new ArrayList<String>();

  List<String> loc = new ArrayList<String>();

  List<String> amount = new ArrayList<String>();

  List<String> vendorid = new ArrayList<String>();

   List<ArrayList<String>> output = new ArrayList<ArrayList<String>>();

  while(rs.next()){



   servicename.add(rs.getString("servicename"));

   serviceno.add(rs.getString("serviceno"));

   vendorid.add(rs.getString("vendorid"));

   loc.add(rs.getString("location"));

   amount.add(rs.getString("amount"));

   cat.add(rs.getString("catagory"));



  }

  output.add((ArrayList<String>) servicename);



   output.add((ArrayList<String>) serviceno);



   output.add((ArrayList<String>) vendorid);

   output.add((ArrayList<String>) loc);



   output.add((ArrayList<String>) amount);

   output.add((ArrayList<String>) cat);



       return output;

  }

  else if(!catagory.equals("default"))

  {

  String sql = "SELECT * FROM services where catagory='"+catagory+"';";

  ResultSet rs = stmt.executeQuery(sql);

  List<String> servicename = new ArrayList<String>();

  List<String> serviceno = new ArrayList<String>();

  List<String> loc = new ArrayList<String>();

  List<String> amount = new ArrayList<String>();

  List<String> vendorid = new ArrayList<String>();

  List<String> cat = new ArrayList<String>();

   List<ArrayList<String>> output = new ArrayList<ArrayList<String>>();

  while(rs.next()){



  servicename.add(rs.getString("servicename"));

  serviceno.add(rs.getString("serviceno"));

  vendorid.add(rs.getString("vendorid"));

  loc.add(rs.getString("location"));

  amount.add(rs.getString("amount"));

  cat.add(catagory);

  }

  output.add((ArrayList<String>) servicename);



   output.add((ArrayList<String>) serviceno);



   output.add((ArrayList<String>) vendorid);

   output.add((ArrayList<String>) loc);



   output.add((ArrayList<String>) amount);

   output.add((ArrayList<String>) cat);



       return output;

  }

  else if(!location.equals("default"))

  {

  String sql = "SELECT * FROM services where location='"+location+"';";

  ResultSet rs = stmt.executeQuery(sql);

  List<String> servicename = new ArrayList<String>();

  List<String> serviceno = new ArrayList<String>();

  List<String> cat = new ArrayList<String>();

  List<String> loc = new ArrayList<String>();

  List<String> amount = new ArrayList<String>();

  List<String> vendorid = new ArrayList<String>();

   List<ArrayList<String>> output = new ArrayList<ArrayList<String>>();

  while(rs.next()){



   servicename.add(rs.getString("servicename"));

   serviceno.add(rs.getString("serviceno"));

   vendorid.add(rs.getString("vendorid"));

   loc.add(location);

   amount.add(rs.getString("amount"));

   cat.add(rs.getString("catagory"));

  }

  output.add((ArrayList<String>) servicename);



   output.add((ArrayList<String>) serviceno);



   output.add((ArrayList<String>) vendorid);

   output.add((ArrayList<String>) loc);



   output.add((ArrayList<String>) amount);

   output.add((ArrayList<String>) cat);



       return output;

  }





  else

  return null;

 } catch (SQLException e) {

  // TODO Auto-generated catch block

  e.printStackTrace();

  return null;

 }





}
 int money = 0;
 public int cost(User user) {
		int sno=user.getSno();
		Connection conn = db.establishConnection();
		PreparedStatement mystmt;
	
		
		try {
			mystmt = conn.prepareStatement(
					"select amount from services where serviceno='" + sno + "';");
			ResultSet rs = mystmt.executeQuery();
			while (rs.next()) {
            money=Integer.parseInt(rs.getString("amount"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return money;
	}

 public static List<String> returnuserdetails() {

 // TODO Auto-generated method stub\





 Connection conn=db.establishConnection();





 Statement stmt = null;

 try {

 stmt = conn.createStatement();



  String sql = "SELECT catagory FROM catagories";

  ResultSet rs = stmt.executeQuery(sql);

  List<String> list = new ArrayList<String>();

  list.add("default");

  while(rs.next()){



  list.add(rs.getString("catagory"));



  }

  return list;

 }catch (SQLException e) {

  // TODO Auto-generated catch block

  e.printStackTrace();

  return null;

 }





 }

 public static List<String> returnuserlocdetails() {

 // TODO Auto-generated method stub\





 Connection conn=db.establishConnection();





 Statement stmt = null;

 try {

 stmt = conn.createStatement();



  String sql = "SELECT location FROM services";

  ResultSet rs = stmt.executeQuery(sql);

  List<String> list = new ArrayList<String>();

  list.add("default");

  while(rs.next()){



  list.add(rs.getString("location"));



  }

  return list;

 }catch (SQLException e) {

  // TODO Auto-generated catch block

  e.printStackTrace();

  return null;

 }

}
public String reduction(User user, String id) {
	// TODO Auto-generated method stub
	int cost = money;
//	System.out.println(cost);
//	System.out.println(id);
	Connection conn = db.establishConnection();
	PreparedStatement mystmt;
	String str=null;
	
	try {
		mystmt = conn.prepareStatement("select money from users where email='"+id+"';");
		ResultSet rs = mystmt.executeQuery();
		while(rs.next())
		{
		String m = rs.getString("money");
		System.out.println(m);
		if(Integer.parseInt(m)>cost)
		{
		mystmt = conn.prepareStatement("update users set money=money-"+cost+" where email = '"+id+"';");
		mystmt.executeUpdate();
		str = "Payment successfully done!";
		}
		else
		{
			str = "Insufficient balance";	
		}
	}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	return str;
}

}