package Project.ij001.model;



import java.util.ArrayList;

import java.util.List;



public class User {

 private String usercat;

 private String userloc;
 private int sno;
 private String submit;
 

 List<String> servicename = new ArrayList<String>();



 List<String> serviceno = new ArrayList<String>();





 List<String> loc = new ArrayList<String>();





 List<String> amount = new ArrayList<String>();

 List<String> vendorid = new ArrayList<String>();

 List<String> cat = new ArrayList<String>();



 public String getUsercat() {

 return usercat;

 }



 public void setUsercat(String usercat) {

 this.usercat = usercat;

 }



 public String getUserloc() {

 return userloc;

 }



 public void setUserloc(String userloc) {

 this.userloc = userloc;

 }



 public List<String> getServicename() {

 return servicename;

 }



 public void setServicename(List<String> servicename) {

 this.servicename = servicename;

 }

 public List<String> getServiceno() {

 return serviceno;

 }



 public void setServiceno(List<String> serviceno) {

 this.serviceno = serviceno;

 }

 public List<String> getLoc() {

 return loc;

 }



 public void setLoc(List<String> loc) {

 this.loc = loc;

 }



 public List<String> getAmount() {

 return amount;

 }



 public void setAmount(List<String> amount) {

 this.amount = amount;

 }



 public List<String> getVendorid() {

 return vendorid;

 }



 public void setVendorid(List<String> vendorid) {

 this.vendorid = vendorid;

 }



 public List<String> getCat() {

 return cat;

 }



 public void setCat(List<String> cat) {

 this.cat = cat;

 }



public int getSno() {
	return sno;
}



public void setSno(int sno) {
	this.sno = sno;
}



public String getSubmit() {
	return submit;
}



public void setSubmit(String submit) {
	this.submit = submit;
}







}