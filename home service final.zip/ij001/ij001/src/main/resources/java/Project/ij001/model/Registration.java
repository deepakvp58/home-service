package Project.ij001.model;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

public class Registration {
    private String firstName;
	
	private String lastName;
	
	private String description;

    
	//@NotNull(message= "Email cannot be null")
    private String email;
    
    //@NotNull(message="Gender cannot be null")
    //@Pattern(regexp = "{A-Za-z}*")
    private String gender;
    
    //@NotBlank(message = "Contact Number cannot be empty")
    //@Digits(integer=10, fraction=0, message = "The contact number should be 10 digits")
    private String contactNum;
    
    //@NotBlank(message = "Age cannot be empty")
    private String age;
    
    private String customer;
    
    //@NotBlank(message = "Password cannot be empty")
    private String password;
    
    //@NotBlank(message = "Choose a Skill")
    private String skill;
    
    //@NotBlank(message = "Money cannot be empty")
    private String money;
    
    //@NotBlank(message = "Select a Role")
    private String roles;
    
    //@NotBlank(message = "VendorID cannot be empty")
    private String vendorid;
    
    
    public String getFirstName() {
           return firstName;
    }
    public void setFirstName(String firstName) {
           this.firstName = firstName;
    }
    public String getLastName() {
           return lastName;
    }
    public void setLastName(String lastName) {
           this.lastName = lastName;
    }
    public String getemail() {
           return email;
    }
    public void setemail(String email) {
           this.email = email;
    }
    public String getGender() {
           return gender;
    }
    public void setGender(String gender) {
           this.gender = gender;
    }
    public String getContactNum() {
           return contactNum;
    }
    public void setContactNum(String contactNum) {
           this.contactNum = contactNum;
    }
    public String getage() {
           return age;
    }
    public void setage(String age) {
           this.age = age;
    }
    public String getPassword() {
           return password;
    }
    public void setPassword(String password) {
           this.password = password;
    }
   
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getMoney() {
		return money;
	}
	public void setMoney(String money) {
		this.money = money;
	}
	public String getRoles() {
		return roles;
	}
	public void setRoles(String roles) {
		this.roles = roles;
	}
	public String getVendorid() {
		return vendorid;
	}
	public void setVendorid(String vendorid) {
		this.vendorid = vendorid;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	

	}

