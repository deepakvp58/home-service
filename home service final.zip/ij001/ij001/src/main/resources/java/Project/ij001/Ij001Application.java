package Project.ij001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("Project.ij001")
public class Ij001Application {

	public static void main(String[] args) {
		SpringApplication.run(Ij001Application.class, args);
	}

}
