package Project.ij001.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import Project.ij001.model.Login;
import Project.ij001.model.User;
import Project.ij001.model.VendorModel;

@Controller
public class VendorController {

	VendorDBClass dbclass = new VendorDBClass();
	private String str;
	@RequestMapping(value = "/vendor", method = RequestMethod.GET)
	public String vendorPage1(@ModelAttribute("vendor") VendorModel vendor, Model model,HttpSession request) {
		
		List<String> contactdetails = dbclass.contactdetails((String) request.getAttribute("user"));
		List<ArrayList<String>> servicenames = dbclass.getValues(vendor,(String) request.getAttribute("user"));
		System.out.println(contactdetails);
		//System.out.println(servicenames);
		model.addAttribute("firstname", contactdetails.get(0));
		model.addAttribute("lastname", contactdetails.get(1));
		model.addAttribute("contactno", contactdetails.get(2));
		model.addAttribute("age", contactdetails.get(3));
		model.addAttribute("gender", contactdetails.get(4));
		model.addAttribute("skills", contactdetails.get(5));
		model.addAttribute("description", contactdetails.get(6));
		model.addAttribute("servicename",servicenames.get(0));
		model.addAttribute("serviceno",servicenames.get(1));
		model.addAttribute("location",servicenames.get(2));
		model.addAttribute("category",servicenames.get(3));
		model.addAttribute("amount", servicenames.get(4));
		return "vendor";

	}

	@RequestMapping(value = "/VendorReg", method = RequestMethod.GET)
	public String vendor(@ModelAttribute("vendor") VendorModel vendor ,Model model, HttpSession request) {
		List<String> contactdetails = dbclass.contactdetails((String) request.getAttribute("user"));
		model.addAttribute("firstname", contactdetails.get(0));
		model.addAttribute("lastname", contactdetails.get(1));
		model.addAttribute("contactno", contactdetails.get(2));
		model.addAttribute("age", contactdetails.get(3));
		model.addAttribute("gender", contactdetails.get(4));
		model.addAttribute("skills", contactdetails.get(5));
		model.addAttribute("description", contactdetails.get(6));
		model.addAttribute("user", (String) request.getAttribute("user"));
		return "vendorreg";
	}
	@RequestMapping(value = "/Vendorsuccess", method = RequestMethod.GET)
	public String vendorPage(@ModelAttribute("vendor") VendorModel vendor,Model model, HttpSession request) {
		List<String> contactdetails = dbclass.contactdetails((String) request.getAttribute("user"));
		model.addAttribute("firstname", contactdetails.get(0));
		model.addAttribute("lastname", contactdetails.get(1));
		model.addAttribute("contactno", contactdetails.get(2));
		model.addAttribute("age", contactdetails.get(3));
		model.addAttribute("gender", contactdetails.get(4));
		model.addAttribute("skills", contactdetails.get(5));
		model.addAttribute("description", contactdetails.get(6));

		List<ArrayList<String>> servicenames = dbclass.getValues(vendor,(String) request.getAttribute("user"));
		model.addAttribute("servicename",servicenames.get(0));
		model.addAttribute("location",servicenames.get(1));
		model.addAttribute("category",servicenames.get(2));
		model.addAttribute("amount", servicenames.get(3));
		dbclass.vendordetails(vendor,(String)request.getAttribute("user"));
	return "vendor";
   }
	@RequestMapping(value = "/Vendorupdate", method = RequestMethod.GET)
	public String vendorupdate(@ModelAttribute("vendor") VendorModel vendor,Model model, HttpSession request) {
		dbclass.updatevalues(vendor,(String) request.getAttribute("user"));
		
		List<String> contactdetails = dbclass.contactdetails((String) request.getAttribute("user"));
		model.addAttribute("firstname", contactdetails.get(0));
		model.addAttribute("lastname", contactdetails.get(1));
		model.addAttribute("contactno", contactdetails.get(2));
		model.addAttribute("age", contactdetails.get(3));
		model.addAttribute("gender", contactdetails.get(4));
		model.addAttribute("skills", contactdetails.get(5));
		model.addAttribute("description", contactdetails.get(6));
		
		List<ArrayList<String>> servicenames = dbclass.getValues(vendor,(String) request.getAttribute("user"));
		model.addAttribute("servicename",servicenames.get(0));
		model.addAttribute("location",servicenames.get(1));
		model.addAttribute("category",servicenames.get(2));
		model.addAttribute("amount", servicenames.get(3));

		return "vendor";
	}
	@ModelAttribute("vendorcat")

	 public List<String> Vendorcat() {
        
	 List<String> list = new ArrayList<String>();

	 list=VendorDBClass.returndetails();
	 
	 return list;

	 }
	@RequestMapping(value = "/serviceupdate", method = RequestMethod.GET)
	public String serviceupdate(@ModelAttribute("vendor") VendorModel vendor,Model model, HttpSession request) {
		return "vendorserv";
	}
	
	@RequestMapping(value = "/servicefetch", method = RequestMethod.GET)
	public String servicefetch(@ModelAttribute("vendor") VendorModel vendor,Model model, HttpSession request) {
		str = vendor.getServiceno();
		return "vendorservedit";
	}
	
	@RequestMapping(value = "/servicevalues", method = RequestMethod.GET)
	public String servicevalues(@ModelAttribute("vendor") VendorModel vendor,Model model, HttpSession request) {
		System.out.println(str);
		dbclass.serviceupdate(vendor,str);
		return "redirect:/vendor";
	}
	@RequestMapping(value = "/logout1", method = RequestMethod.GET)

	 public String logout(@ModelAttribute("vendor") VendorModel vendor,HttpSession request) {

		 request.invalidate();
		//System.out.println(userid);
		
	 return "redirect:/LoginPage";

	 }
}
