package Project.ij001.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import Project.ij001.model.VendorModel;

@Controller
public class AdminController {

	DBClass dbclass = new DBClass();
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String vendorPage1(HttpSession request) {

		return "admin";
		
	}
}