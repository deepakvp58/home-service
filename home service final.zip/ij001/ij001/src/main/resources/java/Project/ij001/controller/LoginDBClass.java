package Project.ij001.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.context.annotation.Configuration;

import Project.ij001.model.Login;
import Project.ij001.model.Registration;

@Configuration
public class LoginDBClass {
	private DBHandler db = new DBHandler();

	public void setValues(Login login) {
		// TODO Auto-generated method stub\
		Connection conn = db.establishConnection();
		PreparedStatement mystmt;
		{
			try {
				mystmt = conn.prepareStatement("select password from Login where username = " + "values(?)");
				String userName = null;
				mystmt.setString(1, userName);

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}