package Project.ij001.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.context.annotation.Configuration;

import Project.ij001.model.VendorModel;

@Configuration
public class VendorDBClass {
	static DBHandler db = new DBHandler();

	public List<ArrayList<String>> getValues(VendorModel vendor, String id) {
		// int i = 0;
		// String userName = null;
		// System.out.println(userName);
		Connection conn = db.establishConnection();
		PreparedStatement mystmt;
		try {
			mystmt = conn.prepareStatement(
					"select servicename,serviceno,location,catagory,amount from users,services where users.vendorid = services.vendorid group by catagory;");
			ResultSet rs = mystmt.executeQuery();
			// System.out.println(userName);
			List<String> servicename = new ArrayList<>();
			List<String> serviceno = new ArrayList<>();
			List<String> location = new ArrayList<>();
			List<String> catagory = new ArrayList<>();
			List<String> amount = new ArrayList<>();
			List<ArrayList<String>> output = new ArrayList<ArrayList<String>>();
			while (rs.next()) {
				servicename.add(rs.getString("servicename"));
				serviceno.add(rs.getString("serviceno"));
				location.add(rs.getString("location"));
				catagory.add(rs.getString("catagory"));
				amount.add(rs.getString("amount"));
			}
			vendor.setVid(id);
 			vendor.setserviceName(servicename);
 			vendor.setServicenumber(serviceno);
			vendor.setLocationlist(location);
			vendor.setCategory(catagory);
			vendor.setAmount(amount);
			output.add((ArrayList<String>) servicename);
			output.add((ArrayList<String>) serviceno);
			output.add((ArrayList<String>) location);
			output.add((ArrayList<String>) catagory);
			output.add((ArrayList<String>) amount);
			// Model model = ;
			// model.addAttribute("servicename",vendor.getserviceName());
			 //System.out.println(id);
			return output;
			// System.out.println(location.get(0));
			// System.out.println(catagory.get(0));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public void vendordetails(VendorModel vendor, String id) {
		// TODO Auto-generated method stub\
		String vendorcat = vendor.getVendorcat();
		String newcat = vendor.getNewcat();
		String location = vendor.getLocation();
		String service = vendor.getService();
		String vendorid = null;
		int amount = vendor.getAmt();
		System.out.println(id);
		Connection conn = db.establishConnection();

		PreparedStatement mystmt;
		PreparedStatement mystmt1;
		Statement stmt = null;
		try {
			if (newcat.length() != 0) {
				stmt = conn.createStatement();
				mystmt1 = conn.prepareStatement("insert into catagories(catagory)" + "values(?)");
				mystmt1.setString(1, newcat);
				mystmt1.execute();
				mystmt = conn.prepareStatement("select vendorid from users where email='"+id+"';");
				ResultSet rs = mystmt.executeQuery();
				rs.next();
				vendorid = rs.getString(1);
				System.out.println(vendorid);
				mystmt = conn.prepareStatement(
						 "insert into services(servicename,vendorid,location,amount,catagory)" + "values(?,?,?,?,?)");
				mystmt.setString(1, service);

				mystmt.setString(2, vendorid);
				mystmt.setString(3, location);
				mystmt.setLong(4, amount);
				mystmt.setString(5, newcat);

				mystmt.execute();
			} else {
				mystmt = conn.prepareStatement("select vendorid from users where email='"+id+"';");
				ResultSet rs = mystmt.executeQuery();
				rs.next();
				vendorid = rs.getString(1);
				System.out.println(vendorid);
				mystmt = conn.prepareStatement(
						"insert into services(servicename,vendorid,location,amount,catagory)" + "values(?,?,?,?,?)");

				mystmt.setString(1, service);
				mystmt.setString(2, vendorid);
				mystmt.setString(3, location);
				mystmt.setLong(4, amount);
				mystmt.setString(5, vendorcat);

				mystmt.execute();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static List<String> returndetails() {
		// TODO Auto-generated method stub\

		Connection conn = db.establishConnection();

		Statement stmt = null;
		try {
			stmt = conn.createStatement();

			String sql = "SELECT catagory  FROM catagories";
			ResultSet rs = stmt.executeQuery(sql);
			List<String> list = new ArrayList<String>();
			while (rs.next()) {

				list.add(rs.getString("catagory"));

			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}

	}
	public List<String> contactdetails(String userid)
	{
		Connection conn = db.establishConnection();
		PreparedStatement mystmt;
		List<String> details = new ArrayList<>();
		//System.out.println(userid);
		try {
			mystmt = conn.prepareStatement(
					"select firstname,lastname,contactno,age,gender,skills,description from users where email = '"+userid+"';");
			ResultSet rs = mystmt.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getString("firstname"));
			details.add(rs.getString("firstname"));
			details.add(rs.getString("lastname"));
			details.add(rs.getString("contactno"));
			details.add(rs.getString("age"));
			details.add(rs.getString("gender"));
			details.add(rs.getString("skills"));
			details.add(rs.getString("description"));
			}
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return details;
	}
	public void updatevalues(VendorModel vendor,String userid)
	{
		String firstname,lastname,age,contactno;
		firstname = vendor.getFirstname();
		lastname = vendor.getLastname();
		age = vendor.getAge();
		contactno = vendor.getContactno();
		System.out.println(firstname+" "+lastname+" "+age+" "+contactno);
		Connection conn = db.establishConnection();
		PreparedStatement mystmt;
		try {
			mystmt = conn.prepareStatement("update users set firstname ='"+firstname+"' where email = '"+userid+"';");
			mystmt.executeUpdate();
			mystmt = conn.prepareStatement("update users set lastname ='"+lastname+"' where email = '"+userid+"';");
			mystmt.executeUpdate();
			mystmt = conn.prepareStatement("update users set age ='"+age+"' where email = '"+userid+"';");
			mystmt.executeUpdate();
			mystmt = conn.prepareStatement("update users set contactno ='"+contactno+"' where email = '"+userid+"';");
			mystmt.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void serviceupdate (VendorModel vendor, String serviceno)
	{
		Connection conn = db.establishConnection();
		PreparedStatement mystmt;
		String location = vendor.getLcn();
		String amount=vendor.getAmountedit();
		String name = vendor.getSname();
		
			
		int sno = Integer.parseInt(serviceno);
		System.out.println(sno);
		try {
			if((amount.length()==0) && (location.length()==0) && (name.length()==0) )
			{
				mystmt = conn.prepareStatement("delete from services where serviceno = "+serviceno+ ";");
				mystmt.executeUpdate();
			}
			else
			{
			mystmt = conn.prepareStatement("update services set servicename ='"+name+"' where serviceno = "+serviceno+";");
			mystmt.executeUpdate();
			mystmt = conn.prepareStatement("update services set location ='"+location+"' where serviceno = "+serviceno+";");
			mystmt.executeUpdate();
			mystmt = conn.prepareStatement("update services set amount ='"+amount+"' where serviceno = "+serviceno+";");
			mystmt.executeUpdate();
			}
	}
		catch(Exception e)
		{
			e.printStackTrace();
		}
}
}
