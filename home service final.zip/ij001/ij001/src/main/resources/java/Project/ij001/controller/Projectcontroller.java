package Project.ij001.controller;

import java.util.ArrayList;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import Project.ij001.model.Login;
import Project.ij001.model.Registration;

@Controller
public class Projectcontroller {
	@Autowired
	private DBClass dbclass = new DBClass();

	@RequestMapping(value = "/HomePage", method = RequestMethod.GET)
	public String homePage() {
		return "homePage";
	}

	@RequestMapping(value = "/LoginPage", method = RequestMethod.GET)
	public String loginPage(@ModelAttribute("login") Login login) {
		// model.addAttribute("login", new Login());
		return "Login";
	}

	// @RequestMapping(value = "/ResultPage1", method = RequestMethod.POST)
	// public String ResultPage1(@ModelAttribute("login") Login login) {
	// //ModelMap model = null;
	// //model.addAttribute("login", new Login());
	// String role = login.getRole();
	// int flag = dbclass.check(login);
	// System.out.println(role);
	// if (flag == 1)
	// {
	// if(role.equals("vendor"))
	// return "vendor";
	// if(role.equals("customer"))
	// return "customer";
	// if(role.equals("admin"))
	// return "admin";
	// }
	// return "InvalidLogin";
	// }

	@RequestMapping(value = "/RegistrationPage", method = RequestMethod.GET)

	public String registrationPage(@ModelAttribute("registration") Registration registration) {

		return "registration";

	}

	@RequestMapping(value = "/ResultPage", method = RequestMethod.POST)

	public String resultPage(@Valid @ModelAttribute("registration") Registration registration, BindingResult error) {

		dbclass.setValues(registration);
		if (error.hasErrors())
			return "registration";
		else
			return "redirect:/LoginPage";

	}

	// @RequestMapping(value = "/ResultPage", method = RequestMethod.POST)
	// public String resultPage(@ModelAttribute("registration") Registration
	// registration) {
	// dbclass.setValues(registration);
	// return "result";
	// }

	@ModelAttribute("gender")
	public List<String> Gender() {

		List<String> list = new ArrayList<String>();
		list.add("Male");
		list.add("Female");
		return list;
	}
}
