package Project.ij001.controller;



import java.util.ArrayList;

import java.util.List;





import java.util.ArrayList;

import java.util.List;



import javax.servlet.http.HttpSession;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.ui.ModelMap;

import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;





import Project.ij001.model.User;



@Controller

public class userController {

 @Autowired

userDbclass dbclass=new userDbclass();
String userid ;
 @RequestMapping(value = "/user", method = RequestMethod.GET)

 public String user(@ModelAttribute("user") User user,HttpSession request) {

	 request.setAttribute("user",(String) request.getAttribute("user"));
	userid = (String) request.getAttribute("user");
	//System.out.println(userid);
	
 return "user";

 }
 
 @RequestMapping(value = "/logout", method = RequestMethod.GET)

 public String logout(@ModelAttribute("user") User user,HttpSession request) {

	 request.invalidate();
	//System.out.println(userid);
	
 return "redirect:/LoginPage";

 }
 @RequestMapping(value = "/paydetails", method = RequestMethod.GET)

 public String userpay(@ModelAttribute("user") User user,Model model,HttpSession request) {

	 request.setAttribute("user",(String) request.getAttribute("user"));
	 int cost=dbclass.cost(user);
	 request.setAttribute("user",(String) request.getAttribute("user"));
	 model.addAttribute("cost",cost);
    return "payment";

 }
 @RequestMapping(value = "/paymentbill", method = RequestMethod.GET)

 public String userbill(@ModelAttribute("user") User user,Model model,HttpSession request) {
	 {
		 //System.out.println((String) request.getAttribute("user"));
		 request.setAttribute("user",(String) request.getAttribute("user"));
		 String str = dbclass.reduction(user,userid);
		 model.addAttribute("result",str);
		 return "paymentbill";
	 }
 }
 @RequestMapping(value = "/usersuccess", method = RequestMethod.GET)

 public String user(@ModelAttribute("user") User user,Model model,HttpSession request) {

 List<ArrayList<String>> servicenames =  dbclass.search(user);

 request.setAttribute("user",(String) request.getAttribute("user"));

  model.addAttribute("servicename",servicenames.get(0));



  model.addAttribute("serviceno",servicenames.get(1));



  model.addAttribute("vendorid",servicenames.get(2));

  model.addAttribute("location",servicenames.get(3));



  model.addAttribute("amount",servicenames.get(4));



  model.addAttribute("catagory",servicenames.get(5));

 return "userservice";

  }



 @ModelAttribute("usercat")



 public List<String> usercat() {



 List<String> list = new ArrayList<String>();



 list= userDbclass.returnuserdetails();



 return list;



 }

 @ModelAttribute("userloc")



 public List<String> userloc() {



 List<String> list1 = new ArrayList<String>();



 list1=userDbclass.returnuserlocdetails();



 return list1;



 }



}